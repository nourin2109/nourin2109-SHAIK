import os
from flask import Flask, request, render_template, redirect, url_for
import cv2
from model import Model  # Import your Model class
from preprocessor import Preprocessor  # Import your Preprocessor class
from path import Path
from typing import Tuple, List
from flask.helpers import send_from_directory
from dataloader_iam import DataLoaderIAM, Batch
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # Build paths inside the project 
app = Flask(__name__)

UPLOAD_FOLDER = 'static'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    # Your other logic here
    css_url = url_for('static', filename='style/style.css')
    return render_template('index.html', template_name='result.html', css_url=css_url)
    
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class FilePaths:
    # Filenames and paths to data.
    fn_char_list = os.path.join(BASE_DIR, 'HW_OR_CHW_Recognization', 'model', 'charList.txt')

def char_list_from_file() -> List[str]:
    with open(FilePaths.fn_char_list) as f:
        return list(f.read())

def get_img_height() -> int:
    #Fixed height for NN.
    return 32


def get_img_size(line_mode: bool = False) -> Tuple[int, int]:
    #Height is fixed for NN, width is set according to training mode (single words or text lines).
    if line_mode:
        return 256, get_img_height()
    return 128, get_img_height()

def recognize_image(model, image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    assert img is not None

    preprocessor = Preprocessor(get_img_size(), dynamic_width=True, padding=16)
    img = preprocessor.process_img(img)

    batch = Batch([img], None, 1)
    recognized, _ = model.infer_batch(batch, True)
    return recognized[0]


@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)

        selected_decoder = int(request.form['decoder'])  # Get selected decoder type from the form

        if file and allowed_file(file.filename):
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)

            model = Model(char_list_from_file(), decoder_type=selected_decoder, must_restore=True, dump=False)
            recognized_text = recognize_image(model, filename)

            return render_template('result.html', image=filename, recognized_text=recognized_text)

    return render_template('index.html')



if __name__ == '__main__':
    app.run(debug=True)
